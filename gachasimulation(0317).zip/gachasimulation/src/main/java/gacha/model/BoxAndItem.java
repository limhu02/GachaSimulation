package gacha.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoxAndItem {
	private String item_code;
	private String item_name;
	private String box_game;
	


}
