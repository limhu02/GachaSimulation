package gacha.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Result {
	private int count;
	private int totalpurchase;
	private double highitemcount;
	private double highitemrate;
}
