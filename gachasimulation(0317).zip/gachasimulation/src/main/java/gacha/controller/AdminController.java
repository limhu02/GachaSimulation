package gacha.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import gacha.model.StartEnd;
import gacha.model.UserInfo;
import gacha.service.AdminService;
import gacha.service.MypageService;
import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {
	@Autowired
	private AdminService adminService;
	@Autowired
	private MypageService mypageService;
	@PostMapping("/admin/update.html")
	public ModelAndView update( String name,String email,MultipartFile profileImage) {
		ModelAndView mav = new ModelAndView("");
		return null;
	}
	
	@PostMapping("/admin/useredit.html")
	public ModelAndView useredit(String user_id,HttpSession session) {
		
		ModelAndView mav =new ModelAndView("index");
		String id= (String) session.getAttribute("user_id");
		if(!id.equals("admin")||id=="") {mav.setViewName("redirect:/login/login.html");}
		UserInfo user = this.adminService.getUserInfoById(user_id);
		mav.addObject("BODY","userDetailModify.jsp");
		mav.addObject("userInfo", user);
		return mav;
	}
	
	
	@GetMapping("/admin/userdetail.html")
	public ModelAndView userDetail(String user_id,HttpSession session) {
		ModelAndView mav = new ModelAndView("index");
		String id= (String) session.getAttribute("user_id");
		if(!id.equals("admin")||id=="") {mav.setViewName("redirect:/login/login.html");
		return mav;}
		
		mav.addObject("BODY","userDetail.jsp");
		UserInfo user = this.mypageService.getUserInfoById(user_id);
		mav.addObject("userInfo",user);
		return mav;
	}
	
	@GetMapping("/admin/userlist.html")
	public ModelAndView userList(Integer pageNo,HttpSession session) {
		ModelAndView mav = new ModelAndView("index");
		String id= (String) session.getAttribute("user_id");
		if(!id.equals("admin")||id=="") {mav.setViewName("redirect:/login/login.html");
		return mav;}
		
		int currentPage = 1;
		if(pageNo != null) currentPage = pageNo;
		int start = (currentPage - 1) * 5;
		int end = ((currentPage - 1) * 5) + 6;
		StartEnd se = new StartEnd(); se.setStart(start); se.setEnd(end);
		List<UserInfo> userList = this.adminService.getUserList(pageNo);
		
		Integer totalCount = this.adminService.getTotaUserlCount();//전체 사용자 수
		 
	
		
		int pageCount = totalCount / 5;
		if(totalCount % 5 != 0) pageCount++;
		mav.addObject("BODY","userList.jsp");
		mav.addObject("userlist",userList);
		mav.addObject("currentPage", pageNo);
        mav.addObject("totalPages",  pageCount);
       
		
		return mav;
	}
	
	

}
