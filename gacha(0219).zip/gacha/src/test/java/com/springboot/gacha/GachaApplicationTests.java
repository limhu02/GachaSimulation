package com.springboot.gacha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GachaApplicationTests {

	@Test
	void contextLoads() {
	}

}
