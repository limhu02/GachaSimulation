package com.springboot.gacha.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.gacha.mapper.EntryMapper;
import com.springboot.gacha.model.User_entry;

@Service
public class EntryService {
    @Autowired
    private EntryMapper entryMapper;
    //회원가입
    public void registerUser(User_entry user) {
        this.entryMapper.insertUser(user);
    }
    
    //ID 중복 체크
    public Integer checkIdDupService(String userId) {
        return entryMapper.checkDupId(userId);
    }
}
