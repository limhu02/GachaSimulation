package com.springboot.gacha.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class User_info {
	private String user_id;
	private String user_pwd;
	private String name;
	private String email;
	private Date reg_date;
	private String profile_image;
}
