package com.springboot.gacha.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.springboot.gacha.model.LoginUser;
import com.springboot.gacha.model.User_info;

@Mapper
public interface LoginMapper {
	// 로그인 사용자 조회
    LoginUser getUser(LoginUser loginUser);
    
    // 아이디 찾기 (이메일 + 닉네임)
    String findUserId(User_info userInfo);

    // 비밀번호 찾기 (이메일 + 닉네임 + 아이디 일치 시 비밀번호 반환)
    String findUserPwd(User_info userInfo);
}
