package com.springboot.gacha.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.gacha.mapper.LoginMapper;
import com.springboot.gacha.model.LoginUser;
import com.springboot.gacha.model.User_info;

@Service
public class LoginService {
    @Autowired
    private LoginMapper loginMapper;

    public LoginUser authenticateUser(LoginUser loginUser) {
        // DB에서 사용자를 조회
        return loginMapper.getUser(loginUser);
    }
    
    // 아이디 찾기
    public String findUserId(User_info userInfo) {
        return loginMapper.findUserId(userInfo);
    }

    // 비밀번호 찾기 (일치하는 경우 비밀번호 반환)
    public String findUserPwd(User_info userInfo) {
        return loginMapper.findUserPwd(userInfo);
    }
}

