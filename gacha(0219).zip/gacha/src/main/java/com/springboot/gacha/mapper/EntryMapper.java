package com.springboot.gacha.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.springboot.gacha.model.User_entry;

@Mapper
public interface EntryMapper {
    void insertUser(User_entry user);
    
    Integer checkDupId(String user_id);
}
