package com.springboot.gacha.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {


    @GetMapping("/board/pride")
    public ModelAndView showPrideBoard() {
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("BODY", "pride.jsp");
        return mav;
    }

    @GetMapping("/board/fail")
    public ModelAndView showFailBoard() {
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("BODY", "fail.jsp");
        return mav;
    }

    @GetMapping("/board/request")
    public ModelAndView showRequestBoard() {
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("BODY", "request.jsp");
        return mav;
    }

    @GetMapping("/board/simulation")
    public ModelAndView showSimulationBoard() {
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("BODY", "simulation.jsp");
        return mav;
    }

    @GetMapping("/board/mypage")
    public ModelAndView showMyPage(HttpSession session) {
        // 세션에서 user_id 가져오기
        String userId = (String) session.getAttribute("user_id");

        // 로그인하지 않은 경우 → login.jsp로 직접 리디렉트
        if (userId == null) {
            return new ModelAndView("redirect:/login/login.html");
        }

        // 로그인한 경우 → 마이페이지 표시
        ModelAndView mav = new ModelAndView("index");
        mav.addObject("BODY", "mypage.jsp");
        return mav;
    }


}
