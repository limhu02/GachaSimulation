package com.springboot.gacha.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.gacha.model.User_entry;
import com.springboot.gacha.service.EntryService;

import jakarta.validation.Valid;

@Controller
public class EntryController {
    @Autowired
    private EntryService entryService;

    // [GET 요청] 회원가입 폼 열기
    @GetMapping("/entry/register.html")
    public ModelAndView showRegisterPage() {
        return new ModelAndView("register");
    }
    // [POST 요청] 회원가입 처리
    @PostMapping("/entry/register.html")
    public ModelAndView registerUser(@Valid User_entry user, BindingResult br) {
        ModelAndView mav = new ModelAndView("register");

        if (br.hasErrors()) {
            mav.getModel().putAll(br.getModel()); // 유효성 검증 오류 추가
            return mav;
        }

        // 회원가입 성공 시
        this.entryService.registerUser(user);
        mav.setViewName("registerSuccess");
        return mav;
    }
    // 계정 중복 검사
    @RequestMapping(value="/entry/idcheck.html")
	public ModelAndView idcheck(String USER_ID) {
		ModelAndView mav = new ModelAndView("idCheckResult");
		Integer count = this.entryService.checkIdDupService(USER_ID);
		if(count > 0) {//이미 계정이 존재하는 경우, 즉 계정 중복
			mav.addObject("DUP","YES");
		}else {//계정이 존재하지 않는 경우, 즉 사용 가능
			mav.addObject("DUP","NO");
		}
		mav.addObject("ID", USER_ID);
		return mav;
	}
}
